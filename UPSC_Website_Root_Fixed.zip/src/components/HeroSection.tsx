import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { BookOpen, Globe, Calendar } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

/* ---------- WebGL Caustic Monolith ---------- */
function initCausticCanvas(canvas: HTMLCanvasElement) {
  const gl = canvas.getContext('webgl', { antialias: true, alpha: true });
  if (!gl) return null;

  const dpr = Math.min(window.devicePixelRatio, 2);

  function resize() {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    gl!.viewport(0, 0, canvas.width, canvas.height);
  }
  resize();
  window.addEventListener('resize', resize);

  // Vertex shader
  const vertSrc = `
    attribute vec2 aPosition;
    void main() {
      gl_Position = vec4(aPosition, 0.0, 1.0);
    }
  `;

  // Fragment shader - Caustic glass effect with Model colors
  const fragSrc = `
    precision mediump float;
    uniform float uTime;
    uniform vec2 uResolution;
    uniform vec2 uMouse;

    float random(vec2 st) {
      return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
    }

    float noise(vec2 st) {
      vec2 i = floor(st);
      vec2 f = fract(st);
      float a = random(i);
      float b = random(i + vec2(1.0, 0.0));
      float c = random(i + vec2(0.0, 1.0));
      float d = random(i + vec2(1.0, 1.0));
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
    }

    float caustic(vec2 uv, float time) {
      vec2 p = uv * 3.0;
      float v = 0.0;
      v += sin(p.x * 2.0 + time);
      v += sin(p.y * 2.0 + time * 0.9);
      v += sin((p.x + p.y) * 1.5 + time * 1.1);
      v += sin(sqrt(p.x * p.x + p.y * p.y + 1.0) * 2.5 + time * 1.2);
      return v / 4.0;
    }

    float chromaticCaustic(vec2 uv, float time, float offset) {
      return caustic(uv + vec2(offset * 0.02, 0.0), time);
    }

    void main() {
      vec2 st = gl_FragCoord.xy / uResolution.xy;
      st.x *= uResolution.x / uResolution.y;

      float time = uTime * 0.3;

      // Central monolith area
      vec2 center = vec2(0.5 * uResolution.x / uResolution.y, 0.5);
      float dist = distance(st, center);
      float monolithMask = smoothstep(0.45, 0.25, dist);

      vec3 color = vec3(0.0);

      // Caustic patterns
      float c1 = chromaticCaustic(st, time * 0.5, -1.0);
      float c2 = chromaticCaustic(st, time * 0.5, 0.0);
      float c3 = chromaticCaustic(st, time * 0.5, 1.0);

      // Model palette: Pink, Blue, Violet
      color.r += smoothstep(0.2, 0.8, c1) * 0.15;
      color.b += smoothstep(0.2, 0.8, c2) * 0.12;
      color.r += smoothstep(0.2, 0.8, c2) * 0.05;
      color.b += smoothstep(0.2, 0.8, c3) * 0.08;
      color.r += smoothstep(0.2, 0.8, c3) * 0.04;

      // Mouse glow
      vec2 mouseNorm = uMouse;
      mouseNorm.x *= uResolution.x / uResolution.y;
      float mouseDist = distance(st, mouseNorm);
      float mouseGlow = smoothstep(0.4, 0.0, mouseDist) * 0.3;
      color += vec3(0.3, 0.2, 0.6) * mouseGlow;

      // Monolith shape
      color *= monolithMask;
      color += vec3(0.02, 0.02, 0.03) * (1.0 - monolithMask) * 0.3;

      // Alpha
      float alpha = 0.6 * monolithMask + mouseGlow * 0.5;
      alpha = clamp(alpha, 0.0, 0.85);

      gl_FragColor = vec4(color, alpha);
    }
  `;

  function compileShader(src: string, type: number) {
    const s = gl!.createShader(type)!;
    gl!.shaderSource(s, src);
    gl!.compileShader(s);
    return s;
  }

  const vs = compileShader(vertSrc, gl.VERTEX_SHADER);
  const fs = compileShader(fragSrc, gl.FRAGMENT_SHADER);
  const prog = gl.createProgram()!;
  gl.attachShader(prog, vs);
  gl.attachShader(prog, fs);
  gl.linkProgram(prog);
  gl.useProgram(prog);

  // Fullscreen quad
  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,1, 1,1, -1,-1, 1,-1]), gl.STATIC_DRAW);
  const aPos = gl.getAttribLocation(prog, 'aPosition');
  gl.enableVertexAttribArray(aPos);
  gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

  const uTime = gl.getUniformLocation(prog, 'uTime');
  const uRes = gl.getUniformLocation(prog, 'uResolution');
  const uMouse = gl.getUniformLocation(prog, 'uMouse');

  gl.uniform2f(uRes, canvas.width, canvas.height);

  let mouseX = 0.5, mouseY = 0.5;
  let targetMouseX = 0.5, targetMouseY = 0.5;

  const handleMouseMove = (e: MouseEvent) => {
    const rect = canvas.getBoundingClientRect();
    targetMouseX = (e.clientX - rect.left) / rect.width;
    targetMouseY = 1.0 - (e.clientY - rect.top) / rect.height;
  };
  canvas.addEventListener('mousemove', handleMouseMove);

  let rafId: number;
  let startTime = performance.now();

  function render() {
    mouseX += (targetMouseX - mouseX) * 0.05;
    mouseY += (targetMouseY - mouseY) * 0.05;

    gl!.uniform1f(uTime, (performance.now() - startTime) / 1000);
    gl!.uniform2f(uMouse, mouseX, mouseY);
    gl!.drawArrays(gl!.TRIANGLE_STRIP, 0, 4);
    rafId = requestAnimationFrame(render);
  }
  render();

  return {
    destroy() {
      cancelAnimationFrame(rafId);
      canvas.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', resize);
      gl!.deleteProgram(prog);
    }
  };
}

/* ---------- Wave Shader Background ---------- */
function initWaveCanvas(canvas: HTMLCanvasElement) {
  const gl = canvas.getContext('webgl', { alpha: true });
  if (!gl) return null;

  const dpr = Math.min(window.devicePixelRatio, 2);

  function resize() {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    gl!.viewport(0, 0, canvas.width, canvas.height);
  }
  resize();
  window.addEventListener('resize', resize);

  const vertSrc = `
    attribute vec2 aVertexPosition;
    void main() {
      gl_Position = vec4(aVertexPosition, 0.0, 1.0);
    }
  `;

  const fragSrc = `
    precision mediump float;
    uniform vec2 u_resolution;
    uniform float u_time;

    float random(vec2 st) {
      return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
    }

    float noise(vec2 st) {
      vec2 i = floor(st);
      vec2 f = fract(st);
      float a = random(i);
      float b = random(i + vec2(1.0, 0.0));
      float c = random(i + vec2(0.0, 1.0));
      float d = random(i + vec2(1.0, 1.0));
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
    }

    void main() {
      vec2 st = gl_FragCoord.xy / u_resolution.xy;
      st.x *= u_resolution.x / u_resolution.y;

      float time = u_time * 0.2;

      vec3 color = vec3(0.0);
      vec2 pos = st * 3.0;

      float n1 = noise(pos + vec2(time, 0.0));
      float n2 = noise(pos - vec2(0.0, time));
      float wave = sin(st.x * 4.0 + n1 * 2.0 + time) * 0.5 + 0.5;
      wave *= cos(st.y * 3.0 + n2 * 2.0 - time) * 0.5 + 0.5;

      vec3 waveColor = mix(
        vec3(1.0, 0.3, 0.54),
        vec3(0.0, 0.83, 1.0),
        wave
      );
      color += waveColor * wave * 0.08;

      float wave2 = sin(st.x * 3.0 - n2 * 2.0 + time) * 0.5 + 0.5;
      vec3 wave2Color = mix(
        vec3(0.55, 0.36, 0.96),
        vec3(0.0, 0.83, 1.0),
        wave2
      );
      color += wave2Color * wave2 * 0.04;

      gl_FragColor = vec4(color, 1.0);
    }
  `;

  function compileShader(src: string, type: number) {
    const s = gl!.createShader(type)!;
    gl!.shaderSource(s, src);
    gl!.compileShader(s);
    return s;
  }

  const vs = compileShader(vertSrc, gl.VERTEX_SHADER);
  const fs = compileShader(fragSrc, gl.FRAGMENT_SHADER);
  const prog = gl.createProgram()!;
  gl.attachShader(prog, vs);
  gl.attachShader(prog, fs);
  gl.linkProgram(prog);
  gl.useProgram(prog);

  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,1, 1,1, -1,-1, 1,-1]), gl.STATIC_DRAW);
  const aPos = gl.getAttribLocation(prog, 'aVertexPosition');
  gl.enableVertexAttribArray(aPos);
  gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

  const uRes = gl.getUniformLocation(prog, 'u_resolution');
  const uTime = gl.getUniformLocation(prog, 'u_time');

  let rafId: number;
  function render() {
    gl!.uniform2f(uRes, canvas.width, canvas.height);
    gl!.uniform1f(uTime, performance.now() / 1000);
    gl!.drawArrays(gl!.TRIANGLE_STRIP, 0, 4);
    rafId = requestAnimationFrame(render);
  }
  render();

  return {
    destroy() {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', resize);
      gl!.deleteProgram(prog);
    }
  };
}

/* ---------- Particle Field ---------- */
function initParticles(canvas: HTMLCanvasElement) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const dpr = Math.min(window.devicePixelRatio, 2);
  let w = 0, h = 0;

  function resize() {
    w = canvas.clientWidth;
    h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resize();
  window.addEventListener('resize', resize);

  interface Particle {
    x: number; y: number; vx: number; vy: number;
    size: number; opacity: number;
  }

  const particles: Particle[] = [];
  const PARTICLE_COUNT = 80;

  for (let i = 0; i < PARTICLE_COUNT; i++) {
    particles.push({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      size: Math.random() * 1.5 + 0.5,
      opacity: Math.random() * 0.3 + 0.1,
    });
  }

  let rafId: number;
  function render() {
    ctx!.clearRect(0, 0, w, h);

    for (const p of particles) {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0) p.x = w;
      if (p.x > w) p.x = 0;
      if (p.y < 0) p.y = h;
      if (p.y > h) p.y = 0;
    }

    // Draw connections
    ctx!.strokeStyle = 'rgba(200, 200, 220, 0.04)';
    ctx!.lineWidth = 0.5;
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 120) {
          ctx!.beginPath();
          ctx!.moveTo(particles[i].x, particles[i].y);
          ctx!.lineTo(particles[j].x, particles[j].y);
          ctx!.stroke();
        }
      }
    }

    // Draw particles
    for (const p of particles) {
      ctx!.beginPath();
      ctx!.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx!.fillStyle = `rgba(220, 220, 235, ${p.opacity})`;
      ctx!.fill();
    }

    rafId = requestAnimationFrame(render);
  }
  render();

  return {
    destroy() {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', resize);
    }
  };
}

/* ---------- Hero Section Component ---------- */
export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const waveCanvasRef = useRef<HTMLCanvasElement>(null);
  const causticCanvasRef = useRef<HTMLCanvasElement>(null);
  const particleCanvasRef = useRef<HTMLCanvasElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const waveCanvas = waveCanvasRef.current;
    const causticCanvas = causticCanvasRef.current;
    const particleCanvas = particleCanvasRef.current;
    if (!waveCanvas || !causticCanvas || !particleCanvas) return;

    const waveRenderer = initWaveCanvas(waveCanvas);
    const causticRenderer = initCausticCanvas(causticCanvas);
    const particleRenderer = initParticles(particleCanvas);

    return () => {
      waveRenderer?.destroy();
      causticRenderer?.destroy();
      particleRenderer?.destroy();
    };
  }, []);

  useEffect(() => {
    // Entrance animations
    const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

    // Label
    if (labelRef.current) {
      gsap.set(labelRef.current, { opacity: 0, y: 30 });
      tl.to(labelRef.current, { opacity: 1, y: 0, duration: 0.8 }, 0.4);
    }

    // Headline - character reveal
    if (headlineRef.current) {
      const text = "Let's Study";
      headlineRef.current.innerHTML = '';
      const chars: HTMLSpanElement[] = [];
      for (const char of text) {
        const span = document.createElement('span');
        span.textContent = char === ' ' ? '\u00A0' : char;
        span.style.display = 'inline-block';
        span.style.opacity = '0';
        headlineRef.current.appendChild(span);
        chars.push(span);
      }
      tl.to(chars, {
        opacity: 1,
        x: 0,
        duration: 0.8,
        stagger: 0.05,
        ease: 'back.out(1.7)',
      }, 0.5);
    }

    // Subheadline
    if (subRef.current) {
      gsap.set(subRef.current, { opacity: 0, y: 30 });
      tl.to(subRef.current, { opacity: 1, y: 0, duration: 0.8 }, 0.8);
    }

    // CTAs
    if (ctaRef.current) {
      gsap.set(ctaRef.current, { opacity: 0, y: 30 });
      tl.to(ctaRef.current, { opacity: 1, y: 0, duration: 0.8 }, 1.0);
    }

    // Stats
    if (statsRef.current) {
      const pills = statsRef.current.querySelectorAll('.stat-pill');
      gsap.set(pills, { opacity: 0, y: 20 });
      tl.to(pills, { opacity: 1, y: 0, duration: 0.6, stagger: 0.1 }, 1.2);
    }

    // Parallax on content
    if (contentRef.current && sectionRef.current) {
      gsap.to(contentRef.current, {
        y: '-15%',
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
      });
    }

    return () => {
      tl.kill();
      ScrollTrigger.getAll().forEach(st => {
        if (st.vars.trigger === sectionRef.current) st.kill();
      });
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      {/* Hero Glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(255, 77, 139, 0.06), transparent)',
        }}
      />

      {/* Wave Shader Background */}
      <canvas
        ref={waveCanvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
        style={{ zIndex: 0 }}
      />

      {/* Particle Field */}
      <canvas
        ref={particleCanvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
        style={{ zIndex: 1 }}
      />

      {/* Caustic Monolith */}
      <div className="absolute right-[5%] top-1/2 -translate-y-1/2 w-[500px] h-[600px] hidden lg:block" style={{ zIndex: 2 }}>
        <canvas
          ref={causticCanvasRef}
          className="w-full h-full"
        />
      </div>

      {/* Content */}
      <div
        ref={contentRef}
        className="relative z-10 w-full max-w-[1200px] mx-auto px-6 py-32"
      >
        <div className="max-w-[600px]">
          <span
            ref={labelRef}
            className="inline-block font-semibold text-xs tracking-[0.15em] uppercase text-[#8A8B96] mb-6"
          >
            UPSC Preparation Hub
          </span>

          <h1
            ref={headlineRef}
            className="text-[#F0F0F5] font-black leading-[1.1] mb-6"
            style={{ fontSize: 'clamp(42px, 8vw, 80px)' }}
          >
            Let&apos;s Study
          </h1>

          <p
            ref={subRef}
            className="text-[#8A8B96] text-lg leading-[1.7] max-w-[480px] mb-8"
          >
            Your comprehensive UPSC preparation companion. Organize subjects, track progress, and access curated study resources — all in one place.
          </p>

          <div ref={ctaRef} className="flex flex-wrap gap-4 mb-10">
            <a
              href="#subjects"
              className="inline-flex items-center px-7 py-3.5 rounded-xl font-semibold text-[15px] text-white transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,77,139,0.3)]"
              style={{ background: '#FF4D8B' }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.background = '#FF6B9F';
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.background = '#FF4D8B';
              }}
            >
              Start Studying
            </a>
            <a
              href="#subjects"
              className="inline-flex items-center px-7 py-3.5 rounded-xl font-semibold text-[15px] text-[#F0F0F5] border border-[#1A1A1E] transition-all duration-300 hover:border-[#8A8B96] hover:bg-[rgba(255,255,255,0.03)]"
            >
              View Subjects
            </a>
          </div>

          <div ref={statsRef} className="flex flex-wrap gap-4">
            <div className="stat-pill flex items-center gap-3">
              <BookOpen size={18} className="text-[#FF4D8B]" />
              <div>
                <div className="text-[#F0F0F5] font-bold text-lg" style={{ fontFamily: "'JetBrains Mono', monospace" }}>12</div>
                <div className="text-[#8A8B96] text-xs font-medium">Subjects</div>
              </div>
            </div>
            <div className="stat-pill flex items-center gap-3">
              <Globe size={18} className="text-[#00D4FF]" />
              <div>
                <div className="text-[#F0F0F5] font-bold text-lg" style={{ fontFamily: "'JetBrains Mono', monospace" }}>500+</div>
                <div className="text-[#8A8B96] text-xs font-medium">Topics</div>
              </div>
            </div>
            <div className="stat-pill flex items-center gap-3">
              <Calendar size={18} className="text-[#8B5CF6]" />
              <div>
                <div className="text-[#F0F0F5] font-bold text-lg" style={{ fontFamily: "'JetBrains Mono', monospace" }}>Daily</div>
                <div className="text-[#8A8B96] text-xs font-medium">Tracker</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
