import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Footer() {
  const ctaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (ctaRef.current) {
      gsap.set(ctaRef.current, { opacity: 0, y: 50 });
      ScrollTrigger.create({
        trigger: ctaRef.current,
        start: 'top 90%',
        onEnter: () => {
          gsap.to(ctaRef.current, { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out' });
        },
        once: true,
      });
    }

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  const resourceLinks = [
    { label: 'Study Planner', href: '#' },
    { label: 'Syllabus', href: '#' },
    { label: 'PYQs', href: '#' },
    { label: 'Notes', href: '#' },
  ];

  return (
    <footer
      className="relative pt-20 pb-10 overflow-hidden"
      style={{
        background: '#0C0C0E',
        borderTop: '1px solid #1A1A1E',
      }}
    >
      {/* Ambient wave gradient */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          background: 'radial-gradient(ellipse 60% 40% at 50% 100%, rgba(255, 77, 139, 0.03), transparent)',
        }}
      />

      <div className="max-w-[1200px] mx-auto px-6 relative z-10">
        {/* CTA Area */}
        <div
          ref={ctaRef}
          className="liquid-glass rounded-3xl p-12 text-center mb-12"
        >
          <h3
            className="text-[#F0F0F5] font-extrabold mb-3"
            style={{ fontSize: 'clamp(24px, 3vw, 32px)' }}
          >
            Ready to Begin Your UPSC Journey?
          </h3>
          <p className="text-[#8A8B96] text-base mb-6">
            Start organizing your study plan today
          </p>
          <a
            href="#subjects"
            className="inline-flex items-center px-8 py-4 rounded-xl font-semibold text-[15px] text-white transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,77,139,0.3)]"
            style={{ background: '#FF4D8B' }}
            onMouseEnter={(e) => {
              (e.target as HTMLElement).style.background = '#FF6B9F';
            }}
            onMouseLeave={(e) => {
              (e.target as HTMLElement).style.background = '#FF4D8B';
            }}
          >
            Get Started
          </a>
        </div>

        {/* Footer Content */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-[#1A1A1E]">
          {/* Brand */}
          <div className="text-center md:text-left">
            <div className="text-[#F0F0F5] font-extrabold text-lg mb-1">
              Let&apos;s Study
            </div>
            <p className="text-[#8A8B96] text-sm">
              Your UPSC preparation companion
            </p>
          </div>

          {/* Links */}
          <div className="flex flex-wrap items-center gap-6">
            {resourceLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-[#8A8B96] text-sm font-medium hover:text-[#F0F0F5] transition-colors duration-300"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-6 text-center">
          <p className="text-[#8A8B96] text-[13px] opacity-50">
            &copy; 2024 Let&apos;s Study. Built for UPSC aspirants.
          </p>
        </div>
      </div>
    </footer>
  );
}
